package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;
import p000a.p062s.C0756c;

public final class RemoteActionCompat implements C0756c {

    /* renamed from: a */
    public IconCompat f3383a;

    /* renamed from: b */
    public CharSequence f3384b;

    /* renamed from: c */
    public CharSequence f3385c;

    /* renamed from: d */
    public PendingIntent f3386d;

    /* renamed from: e */
    public boolean f3387e;

    /* renamed from: f */
    public boolean f3388f;
}
